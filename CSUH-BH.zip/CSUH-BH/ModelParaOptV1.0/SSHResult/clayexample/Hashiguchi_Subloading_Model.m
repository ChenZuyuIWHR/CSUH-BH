%Hashiguchi�¼�����ģ�ͼ������(Nakai2004Compression_��p)
%ʹ�õ�e-lnp�ռ��е����Թ�ϵ
%%% cu
% clear;clc;close all;
% PARAx=[1.139	0.408	0.005	0.061	0.751	50	0	0];%M,v,kapa,landa,N,u_R,phi_d,mu(��)
% myType=1;%1��������ˮCU��2������p��3����Χѹ����CD��4��������K0��5��������ѹ��ISO
% b=[0,0,0,0,0,0];%bֵ������
% sc=[770,616,513.3,385,192.5,77];%Χѹ
% e0=[0.345,0.3455,0.346,0.35,0.356,0.367];%��ʼ��϶��
% totlee1=0.10;%�����Ӧ��e1
% number=3000;% ��������number=2500;%epsilon1 ����
% filename = 'LowerCromerTillClay-HashiguchiSubloading-THEORY-CU ����.xlsx';

%%% cd
% clear;clc;close all;
% PARAx=[1.139	0.408	0.005	0.061	0.751	50	0	0];%M,v,kapa,landa,N,u_R,phi_d,mu(��)
% myType=3;%1��������ˮCU��2������p��3����Χѹ����CD��4��������K0��5��������ѹ��ISO
% b=[0,0,0,0,0,0];%bֵ������
% sc=[770,616,513.3,385,192.5,77];%Χѹ
% e0=[0.345,0.3455,0.346,0.35,0.356,0.367];%��ʼ��϶��
% totlee1=0.14;%�����Ӧ��e1
% number=3000;% ��������number=2500;%epsilon1 ����
% filename = 'LowerCromerTillClay-HashiguchiSubloading-THEORY-CD ����.xlsx';



%%% cd
clear;clc;close all;
PARAx=[1.139	0.408	0.005	0.061	0.751	50	0	0];%M,v,kapa,landa,N,u_R,phi_d,mu(��)
myType=5;%1��������ˮCU��2������p��3����Χѹ����CD��4��������K0��5��������ѹ��ISO
b=[0];%bֵ������
sc=[1];%Χѹ
e0=[0.751];%��ʼ��϶��
totlee1=0.12;%�����Ӧ��e1
number=5000;% ��������number=2500;%epsilon1 ����
filename = 'LowerCromerTillClay-HashiguchiSubloading-THEORY-ISO ����.xlsx';
%% ����

M=PARAx(1);
phi=asind(3*M/(6+M));%�� Eq.(78)
v=PARAx(2);%para4, Poisson's ratio
kapa=PARAx(3);%para3=��
landa=PARAx(4);%para2=��
N=PARAx(5);%F0
u_R=PARAx(6);%Eq.(49)
% % ������������������ճ��ʱΪ0��
phi_d=PARAx(7);%Eq.(85) ��d
mu=PARAx(8);%Eq.(84)   33.7*pi/180

de1=totlee1/number*ones(1,number);%��1���� epsilon1
S1=zeros(1,number);%��Ӧ�� ��1
S2=zeros(1,number);
S3=zeros(1,number);
p=zeros(1,number);
q=zeros(1,number);
chi=zeros(1,number);
R=zeros(1,number);
e1=zeros(1,number);%��130187
e2=zeros(1,number);
e3=zeros(1,number);
ev=zeros(1,number);%�ܵ�����v
evp=zeros(1,number);%�������Ӧ���v
ed=zeros(1,number);%��d ����Ӧ��
n=zeros(1,number);%Ӧ����yita
nz=zeros(1,number);%��ʵӦ���ռ�Ӧ����yita
e=zeros(1,number);%��϶��
E=zeros(1,number);%����ģ��
u=zeros(1,number);%��ѹ
yita=zeros(1,number);

scAlf=sprintfc('%g',sc);%����������ת�����ַ�������
OCR=e0;
scNum=length(sc);
for im=1:scNum
    sheet=im;
    S1(1)=sc(im)+0.0001;S2(1)=sc(im);S3(1)=sc(im);%������Ӧ��
    e(1)=e0(im);%��ʼ��϶��
    ck=kapa/(1+e0(im));
    cp=(landa-kapa)/(1+e0(im));
    three='abcdefghijklmn';
    F0=exp((N-landa*log(sc(im))-e0(im))/(landa-kapa)+log(sc(im))); %�ý��ŵ���ع�ʽ��������e-lnp�ռ��е����Թ�ϵ
    R(1)=sc(im)/F0;
    OCR(im)=1/R(1);
    
    for in=1:number
        %     if(in==2)
        %         break
        %     end
        q(in)=1/sqrt(2)*sqrt((S1(in)-S2(in))^2+(S2(in)-S3(in))^2+(S1(in)-S3(in))^2);
        p(in)=(S1(in)+S2(in)+S3(in))/3;
        yita(in)=q(in)/p(in);
        
        sig_star_norm=norm1(S1(in)-p(in),S2(in)-p(in),S3(in)-p(in));
        sin_3theta=sqrt(6)*((S1(in)-p(in))^3+(S2(in)-p(in))^3+(S3(in)-p(in))^3)/(sig_star_norm)^3;%Eq.(86)
        m=2*sqrt(6)*sind(phi)/(3-sind(phi)*sin_3theta);%Eq.(78)
        chi(in)=sig_star_norm/p(in)/m;%Eq.(77)
        
        dfdp=1+chi(in)^2;
        dfdchi=2*p(in)*chi(in);
        
        dpdS1=1/3;dpdS2=1/3;dpdS3=1/3;
        %chi=1/m*sqrt(((S1-p)/p)^2+((S2-p)/p)^2+((S3-p)/p)^2)
        dchidp=sqrt(2/3)/m*q(in)/(-p(in)^2);%
        dchidq=sqrt(2/3)/m/p(in);
        
        dqdS1=-(2^(1/2)*(-4*S1(in)+ 2*S2(in) + 2*S3(in)))/(4*((S1(in) - S2(in))^2 + (S1(in) - S3(in))^2 + (S2(in) - S3(in))^2)^(1/2));
        dqdS2=-(2^(1/2)*(2*S1(in) - 4*S2(in) + 2*S3(in)))/(4*((S1(in) - S2(in))^2 + (S1(in) - S3(in))^2 + (S2(in) - S3(in))^2)^(1/2));
        dqdS3=-(2^(1/2)*(2*S1(in) + 2*S2(in) - 4*S3(in)))/(4*((S1(in) - S2(in))^2 + (S1(in) - S3(in))^2 + (S2(in) - S3(in))^2)^(1/2));
        
        dchidS1=dchidp*dpdS1+dchidq*dqdS1;
        dchidS2=dchidp*dpdS2+dchidq*dqdS2;
        dchidS3=dchidp*dpdS3+dchidq*dqdS3;
        
        dfdS1=dfdp*dpdS1+dfdchi*dchidS1;
        dfdS2=dfdp*dpdS2+dfdchi*dchidS2;
        dfdS3=dfdp*dpdS3+dfdchi*dchidS3;
        
        dfdS_norm=norm1(dfdS1,dfdS2,dfdS3);
        N1=dfdS1/dfdS_norm;
        N2=dfdS2/dfdS_norm;
        N3=dfdS3/dfdS_norm;
        
        N_ave=1/3*(N1+N2+N3);
        m_d=2*sqrt(6)*sind(phi_d)/(3-sind(phi_d)*sin_3theta);%Eq.(85)
        %zbl
        
        h=(N1+N2+N3)+mu*norm1(N1-N_ave,N2-N_ave,N3-N_ave)*(sig_star_norm/p(in)-m_d);%Eq.(84)
        
        %Mp=(1/(landa-kapa)*h-u_R*log(R(in))/R(in))*(N1*S1(in)+N2*S2(in)+N3*S3(in));% ;
        Mp=((1+e0(im))/(landa-kapa)*h-u_R*log(R(in))/R(in))*(N1*S1(in)+N2*S2(in)+N3*S3(in));%ʹ�ý���ģ�͵�F��ʽ
        
        E=3*(1-2*v)*p(in)/ck;
        C11=1/E;
        C12=-v/E;
        C13=-v/E;
        C21=-v/E;
        C22=1/E;
        C23=-v/E;
        C31=-v/E;
        C32=-v/E;
        C33=1/E;
        %�ж�������ʵ��
        if myType==1
            % %     ʦ�����᲻��ˮ����ͬ��b��
            dS1=de1(in)/((C11+b(im)*C12)-(C11+C21+C31+b(im)*(C12+C22+C32))*((1-b(im))*C12+C13)/(C13+C23+C33+(1-b(im))*(C12+C22+C32)));
            dS3=-(C11+C21+C31+b(im)*(C12+C22+C32))*dS1/(C13+C23+C33+(1-b(im))*(C12+C22+C32));
            dS2=b(im)*dS1+(1-b(im))*dS3;
            de2=(C21+b(im)*C22)*dS1+((1-b(im))*C22+C23)*dS3;
            de3=(C31+b(im)*C32)*dS1+((1-b(im))*C32+C33)*dS3;
        elseif myType==2
            %�ҵĵ�p
            dS1=(b(im)-2)*de1(in)/(-2*C11+b(im)*C11+C12-2*b(im)*C12+C13+b(im)*C13);
            dS2=(2*b(im)-1)*de1(in)/(2*C11-b(im)*C11-C12+2*b(im)*C12-C13-b(im)*C13);
            dS3=(1+b(im))*de1(in)/(-2*C11+b(im)*C11+C12-2*b(im)*C12+C13+b(im)*C13);
            de2=C21*dS1-C22*dS1-C22*dS3+C23*dS3;
            de3=C31*dS1-C32*dS1-C32*dS3+C33*dS3;
        elseif myType==3
            %�ҵ�Χѹ����
            dS1=de1(in)/(C11+b(im)*C12);
            dS2=b(im)*de1(in)/(C11+b(im)*C12);
            dS3=0;
            de2=(C21+b(im)*C22)*dS1;
            de3=(C31+b(im)*C32)*dS1;
        elseif myType==4
            %����ѹ��
            dS1=(C22- b(im)* C22 + C23)* de1(in)/( b(im)* (C12* C21-C11* C22-C13 *C22+C12 *C23) - C13* C21 + C11* C22  + C11 *C23 -C12 *C21 );
            dS2=(-C21 + b(im)*(C21+C23)  )*de1(in)/( b(im)*(C12*C21-  C11*C22-  C13*C22+  C12*C23)  - C13*C21 + C11*C22   + C11*C23 -C12*C21 );
            dS3=(C21 + b(im)* C22)* de1/( b(im)*( C12* C21+ C11*C22+ C13*C22- C12*C23) + C13*C21 - C11*C22   - C11*C23 +C12*C21);
            de2=0;
            de3=0;
        elseif myType==5
            %����ѹ��
            dS1=de1(in)/(C11+C12+C13);
            dS2=dS1;
            dS3=dS1;
            de2=(C21+C22+C23)*dS1;
            de3=(C31+C32+C33)*dS1;
        end
        
        Dp=[0;0;0];
        
        
        if(dfdS1*dS1+dfdS2*dS2+dfdS3*dS3>0)%��ж���ж�
            A=1/Mp;
            %  A=cp;%�˻���������
            C11=1/E+A*N1*N1;
            C12=-v/E+A*N1*N2;
            C13=-v/E+A*N1*N3;
            C21=-v/E+A*N2*N1;
            C22=1/E+A*N2*N2;
            C23=-v/E+A*N2*N3;
            C31=-v/E+A*N3*N1;
            C32=-v/E+A*N3*N2;
            C33=1/E+A*N3*N3;
            %�ж�������ʵ��
            if myType==1
                % %     ʦ�����᲻��ˮ����ͬ��b��
                dS1=de1(in)/((C11+b(im)*C12)-(C11+C21+C31+b(im)*(C12+C22+C32))*((1-b(im))*C12+C13)/(C13+C23+C33+(1-b(im))*(C12+C22+C32)));
                dS3=-(C11+C21+C31+b(im)*(C12+C22+C32))*dS1/(C13+C23+C33+(1-b(im))*(C12+C22+C32));
                dS2=b(im)*dS1+(1-b(im))*dS3;%�������b�Ķ����󵼿ɵ�
                de2=(C21+b(im)*C22)*dS1+((1-b(im))*C22+C23)*dS3;
                de3=(C31+b(im)*C32)*dS1+((1-b(im))*C32+C33)*dS3;
            elseif myType==2
                %�ҵĵ�p
                dS1=(b(im)-2)*de1(in)/(-2*C11+b(im)*C11+C12-2*b(im)*C12+C13+b(im)*C13);
                dS2=(2*b(im)-1)*de1(in)/(2*C11-b(im)*C11-C12+2*b(im)*C12-C13-b(im)*C13);
                dS3=(1+b(im))*de1(in)/(-2*C11+b(im)*C11+C12-2*b(im)*C12+C13+b(im)*C13);
                de2=C21*dS1-C22*dS1-C22*dS3+C23*dS3;
                de3=C31*dS1-C32*dS1-C32*dS3+C33*dS3;
            elseif myType==3
                %�ҵ�Χѹ����
                dS1=de1(in)/(C11+b(im)*C12);
                dS2=b(im)*de1(in)/(C11+b(im)*C12);
                dS3=0;
                de2=(C21+b(im)*C22)*dS1;
                de3=(C31+b(im)*C32)*dS1;
            elseif myType==4
                %����ѹ��
                dS1=(C22- b(im)* C22 + C23)* de1(in)/( b(im)* (C12* C21-C11* C22-C13 *C22+C12 *C23) - C13* C21 + C11* C22  + C11 *C23 -C12 *C21 );
                dS2=(-C21 + b(im)*(C21+C23)  )*de1(in)/( b(im)*(C12*C21-  C11*C22-  C13*C22+  C12*C23)  - C13*C21 + C11*C22   + C11*C23 -C12*C21 );
                dS3=(C21 + b(im)* C22)* de1(in)/( b(im)*( C12* C21+ C11*C22+ C13*C22- C12*C23) + C13*C21 - C11*C22   - C11*C23 +C12*C21);
                de2=0;
                de3=0;
            elseif myType==5
                %����ѹ��
                dS1=de1(in)/(C11+C12+C13);
                dS2=dS1;
                dS3=dS1;
                de2=(C21+C22+C23)*dS1;
                de3=(C31+C32+C33)*dS1;
            end
            C1_1=A*N1*N1;
            C1_2=A*N1*N2;
            C1_3=A*N1*N3;
            C2_1=A*N2*N1;
            C2_2=A*N2*N2;
            C2_3=A*N2*N3;
            C3_1=A*N3*N1;
            C3_2=A*N3*N2;
            C3_3=A*N3*N3;
            Dp=[C1_1,C1_2,C1_3;C2_1,C2_2,C2_3;C3_1,C3_2,C3_3]*[dS1;dS2;dS3];%����Ӧ����
            
            C11=1/E;
            C12=-v/E;
            C13=-v/E;
            C21=-v/E;
            C22=1/E;
            C23=-v/E;
            C31=-v/E;
            C32=-v/E;
            C33=1/E;
            De=[C11,C12,C13;C21,C22,C23;C31,C32,C33]*[dS1;dS2;dS3];%����Ӧ��
            
        end
        R(in+1)=R(in)-u_R*log(R(in))*norm1(Dp(1,1),Dp(2,1),Dp(3,1));
        S1(in+1)=S1(in)+dS1;
        S2(in+1)=S2(in)+dS2;
        S3(in+1)=S3(in)+dS3;
        e1(in+1)=e1(in)+de1(in);
        e2(in+1)=e2(in)+de2;
        e3(in+1)=e3(in)+de3;
        ev(in+1)=e1(in+1)+e2(in+1)+e3(in+1);
        ed(in+1)=sqrt(2)/3*sqrt((e1(in+1)-e2(in+1))^2+(e1(in+1)-e3(in+1))^2+(e3(in+1)-e2(in+1))^2);
        e(in+1)=e0(im)-ev(in+1)*(1+e0(im));%��϶��
        if myType==1
            u(in+1)=S3(1)-S3(in+1);
        else
            u(in+1)=0.0;
        end
        
        for un=1:number
            if(p(un)<0)
                num=un-1;
                break;
            end
        end
        if(un==number)
            num=number;
        end
        
    end
    %��ͼ
    color=[1 0 0;0 1 0;0 0 1;0.5 0.1 0;0 0.3 0.4;0.6 0.7 0.2;0.5 0.8 0.9;0 0.2 0.1];
    linestyle=['- ';'--';': ';'-.'];
    marker=['x','o','+','*'];
    lsN=1;
    figure(1)
    subplot(3, 2,1)%e1-q
    %       h1=plot((e1(1:number)*100)',(S1(1:number)-S3(1:number))','Linestyle',linestyle(lsN),'color',color(im,:),'LineWidth',1);...
    %       xlabel('��1 %'),ylabel('q/kPa');title('e1-q');grid on;hold on;%e1-q
    
    h1=plot(((e1(1:number)-e3(1:number))*100*2/3)',((S1(1:number)-S3(1:number))/sc(im))','Linestyle',linestyle(lsN),'color',color(im,:),'LineWidth',1);...
        xlabel('��d %'),ylabel('q/p');title('ed-q/p');grid on;hold on;%ed-q/p
    % if(im<5)
    %      h1=scatter((expData1(:,(im-1)*4+1))',(expData1(:,(im-1)*4+2))',50,'marker',marker(im),'markeredgecolor',color(im,:),'LineWidth',1);...
    % end
    %   annotation('textbox', [0.2,0.4+0.1*im,0.1,0.1],...
    %            'String', sc(im))
    subplot(3, 2,2)%p-q
    h2=plot(p(1:num)'/p(num),q(1:num)'/p(num),'color',color(im,:),'LineWidth',4);...
        xlabel('p/kPa'),ylabel('q/kPa');title('p-q');grid on;hold on;%pz-qz
    subplot(3, 2,3)%e1-e
    h3=plot(((e1(1:number)-e3(1:number))*100*2/3)',(ev(1:num)*100)','Linestyle',linestyle(lsN),'color',color(im,:),'LineWidth',1);...
        xlabel('��1 %'),ylabel('��v %');title('��1-��v');grid on;hold on;
    %   if(im<5)
    %   h3=scatter((expData2(:,(im-1)*4+1))',(expData2(:,(im-1)*4+2))',50,'marker',marker(im),'markeredgecolor',color(im,:),'LineWidth',1);...
    %       xlabel('��d %'),ylabel('��v %');title('��d-��v');grid on;hold on;
    %   end
    subplot(3, 2,4)%lnp-e  log(X) returns the natural logarithm ln(x) of each element in array X.
    h4=semilogx((p(1:number))',(e(1:number))','color',color(im,:),'LineWidth',4);...
        xlabel('lnp/kPa'),ylabel('e');title('lnp-e');grid on;hold on;%e1-q
    subplot(3, 2,5)%e1-u
    h5=plot((e1(1:number)*100)',(u(1:number))','color',color(im,:),'LineWidth',4);...
        xlabel('��1 %'),ylabel('u/kPa');title('��1-u');grid on;hold on;%e1-q
    subplot(3, 2,6)%e1-e
    h6=plot((e1(1:number))',(e(1:number)*100)','color',color(im,:),'LineWidth',4);...
        xlabel('��1 %'),ylabel('e');title('��1-e');grid on;hold on;%e1-q
    figure(2)
    plot((e1(1:number)*100)',(R(1:number))','color',color(im,:),'Linestyle',linestyle(lsN),'LineWidth',4);...
        xlabel('��1 %'),ylabel('R');title('��1-R');grid on;hold on;%e1-R
    
    % xlswrite(filename,[((e1(1:num)-e3(1:num))*100*2/3)',(q(1:num)./p(1:num))',(ev(1:num)*100)',R(1:num)'],['OCR=',num2str(OCR(im))]);
    
    switch myType
        case 1
            % till ճ�� CU
            titou= {'e1','Matlab-q/2sigc','p/2sigc','Matlab-q/2sigc',' ','e1','u'};
            xlswrite(filename,titou,sheet,'B1')
            multiN=1;%100:�ٷ�����ʽ��1��С����ʽ
            xlswrite(filename,(e1(1:num)*multiN)',sheet,'B2')
            xlswrite(filename,((S1(1:num)-S3(1:num))./(2*770))',sheet,'C2');%LowerCromerTill1
            xlswrite(filename,((S1(1:num)+S3(1:num))./(2*770))',sheet,'D2');%LowerCromerTill1
            xlswrite(filename,((S1(1:num)-S3(1:num))./(2*770))',sheet,'E2');%LowerCromerTill1
            xlswrite(filename,(e1(1:num)*multiN*100)',sheet,'G2')
            xlswrite(filename,(u(1:num))',sheet,'H2')
        case 3
            %     % till ճ�� CD
            titou= {'e1','Matlab-q/2sigc','e1','ev'};
            xlswrite(filename,titou,sheet,'B1')
            multiN=1;%100:�ٷ�����ʽ��1��С����ʽ
            xlswrite(filename,(e1(1:num)*multiN)',sheet,'A2')
            xlswrite(filename,((S1(1:num)-S3(1:num))./(2*770))',sheet,'B2');%LowerCromerTill1
            xlswrite(filename,(e1(1:num)*multiN)',sheet,'C2')
            xlswrite(filename,(ev(1:num))',sheet,'D2')
        case 5
            titou= {'e1%','Matlab-q','Matlab-p','Matlab-ev%','Matlab-u'};
            xlswrite(filename,titou,sheet,'I1')
            multiN=100;%100:�ٷ�����ʽ��1��С����ʽ
            xlswrite(filename,(e1(1:num)*multiN)',sheet,'I2')
            xlswrite(filename,(q(1:num))',sheet,'J2')
            xlswrite(filename,(p(1:num))',sheet,'K2')
            xlswrite(filename,(ev(1:num)*multiN)',sheet,'L2')
            xlswrite(filename,(u(1:num))',sheet,'M2')
            xlswrite(filename,(e(1:num))',sheet,'N2')
            
        otherwise
            titou= {'e1%','Matlab-q','Matlab-p','Matlab-ev%','Matlab-u'};
            xlswrite(filename,titou,sheet,'I1')
            multiN=100;%100:�ٷ�����ʽ��1��С����ʽ
            xlswrite(filename,(e1(1:num)*multiN)',sheet,'I2')
            xlswrite(filename,(q(1:num))',sheet,'J2')
            xlswrite(filename,(p(1:num))',sheet,'K2')
            xlswrite(filename,(ev(1:num)*multiN)',sheet,'L2')
            xlswrite(filename,(u(1:num))',sheet,'M2')
    end
end

figure(1)
%�ж�������ʵ��
if myType==1
    % %     ʦ�����᲻��ˮ����ͬ��b��
    suptitle('����ˮ�����������');
elseif myType==2
    %�ҵĵ�p
    suptitle('��p�����������');
elseif myType==3
    %�ҵ�Χѹ����
    suptitle('Χѹ���������������');
elseif myType==4
    %����ѹ��
    suptitle('����ѹ������');
end
legend(scAlf,'Location','northoutside','Orientation','horizontal');%��ͼ��
disp('end~');

function c=norm1(a1,a2,a3)
c=sqrt(a1^2+a2^2+a3^2);
end

